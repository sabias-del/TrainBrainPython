for i in range(1,5,1):
    print(i)
else:
    print("END CIRCLE")