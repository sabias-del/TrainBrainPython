age=input("Твой Возраст? ")
name=input("Имя ")
print('Возраст {0}--{1}лет.'.format(name, age))
print('Почему {0} забавляется с этим Python?'.format(name))