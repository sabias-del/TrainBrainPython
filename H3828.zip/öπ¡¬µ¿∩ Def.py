def sayHello():
    print("Привет Мир")
sayHello()
sayHello()